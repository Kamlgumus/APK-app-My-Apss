package com.ornek.uygulama;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText("Merhaba! APKForge calisiyor.");
        t.setTextSize(24);
        setContentView(t);
    }
}
